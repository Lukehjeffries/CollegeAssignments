# bayesian_naive_bayes_assignment.py
# Complete implementation for Bayesian inference and Naive Bayes assignment
# Includes Beta-Binomial, Gaussian-Gaussian, PPC, Naive Bayes, and optional mini-project scaffolds

import numpy as np
from dataclasses import dataclass
from typing import Tuple
import scipy.stats as st
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB, BernoulliNB, GaussianNB
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay
from sklearn.model_selection import train_test_split
from sklearn.calibration import CalibratedClassifierCV
import matplotlib.pyplot as plt

np.set_printoptions(precision=4, suppress=True)

# ------------------------------
# Stage 1 — Beta-Binomial
# ------------------------------

@dataclass
class BetaBinomial:
    alpha: float
    beta: float
    k: int
    n: int

    def posterior_params(self) -> Tuple[float,float]:
        return self.alpha + self.k, self.beta + (self.n - self.k)

    def posterior_mean(self) -> float:
        a, b = self.posterior_params()
        return a / (a + b)

    def map_estimate(self) -> float:
        a, b = self.posterior_params()
        if a > 1 and b > 1:
            return (a - 1) / (a + b - 2)
        return np.nan

    def posterior_predictive_next(self) -> float:
        return self.posterior_mean()

def showcase_beta_binomial():
    bb = BetaBinomial(alpha=2.0, beta=2.0, k=30, n=50)
    print("Beta_Binomial showcase")
    print("Posterior (a,b):", bb.posterior_params())
    print("Posterior mean:", bb.posterior_mean())
    print("MAP:", bb.map_estimate())
    print("Predictive p:", bb.posterior_predictive_next())
    print("-"*50)


# Stage 2


def gaussian_posterior(mu0, tau0_sq, sigma_sq, x):
    n = len(x)
    xbar = np.mean(x)
    prec0 = 1.0 / tau0_sq
    prec  = 1.0 / sigma_sq
    post_var = 1.0 / (prec0 + n * prec)
    post_mean = post_var * (prec0*mu0 + n*prec*xbar)
    return post_mean, post_var

def showcase_gaussian_posterior():
    rng = np.random.default_rng(0)
    true_mu, sigma = 1.5, 1.0
    x = rng.normal(true_mu, sigma, size=30)
    mu_post, var_post = gaussian_posterior(mu0=0.0, tau0_sq=4.0, sigma_sq=sigma**2, x=x)
    print("Gaussian Posterior showcase")
    print("Posterior mean:", mu_post)
    print("Posterior variance:", var_post)
    print("-"*50)
    return x, mu_post, var_post, sigma


# Stage 3


def ppc_gaussian(mu_post, var_post, sigma_sq, T=500, n=30, seed=0):
    rng = np.random.default_rng(seed)
    sims = []
    for _ in range(T):
        mu_sim = rng.normal(mu_post, np.sqrt(var_post))
        x_new = rng.normal(mu_sim, np.sqrt(sigma_sq), size=n)
        sims.append([np.mean(x_new), np.var(x_new)])
    return np.array(sims)

def showcase_ppc_gaussian():
    x, mu_post, var_post, sigma = showcase_gaussian_posterior()
    sims = ppc_gaussian(mu_post, var_post, sigma_sq=sigma**2, n=len(x))
    obs_stats = np.array([np.mean(x), np.var(x)])
    pval_mean = (sims[:,0] <= obs_stats[0]).mean()
    pval_var  = (sims[:,1] <= obs_stats[1]).mean()
    print("PPC p-values (mean, var):", (pval_mean, pval_var))
    print("-"*50)


# Stage 4


def showcase_naive_bayes_toy():
    docs = [
        ("team wins match", 1), ("player scores goal", 1),
        ("election debate policy", 0), ("policy vote election", 0),
        ("team scores again", 1), ("debate team policy", 0)
    ]
    corpus, y = zip(*docs); y = np.array(y)
    vec = CountVectorizer()
    X = vec.fit_transform(corpus).toarray()
    V = X.shape[1]
    alpha = 1.0

    # Class priors
    pi = np.bincount(y) / len(y)
    phi = np.zeros((2,V))
    for c in [0,1]:
        counts = X[y==c].sum(axis=0)
        phi[c] = (counts + alpha) / (counts.sum() + alpha*V)

    # Predict
    def predict_nb(Xrow):
        logp = np.log(pi.copy())
        for c in [0,1]:
            logp[c] += (Xrow * np.log(phi[c] + 1e-12)).sum()
        return int(np.argmax(logp))

    yhat = np.array([predict_nb(x) for x in X])
    print("Naive Bayes Toy showcase Accuracy:", (yhat == y).mean())
    print("-"*50)


# Stage 4b 


def showcase_naive_bayes_sms():
    sms_docs = [
        ("win cash now free entry", 1),
        ("urgent claim prize call now", 1),
        ("free tickets win now", 1),
        ("lets meet for lunch", 0),
        ("are you coming to class", 0),
        ("see you at the game", 0),
        ("free lunch offer today", 1),
        ("can we call later", 0)
    ]
    corpus_sms, y_sms = zip(*sms_docs)
    y_sms = np.array(y_sms)
    vec_sms = CountVectorizer()
    X_sms = vec_sms.fit_transform(corpus_sms).toarray()
    V_sms = X_sms.shape[1]
    alpha_sms = 1.0

    pi_sms = np.bincount(y_sms) / len(y_sms)
    phi_sms = np.zeros((2,V_sms))
    for c in [0,1]:
        counts = X_sms[y_sms == c].sum(axis=0)
        phi_sms[c] = (counts + alpha_sms) / (counts.sum() + alpha_sms*V_sms)

    def predict_nb_sms(xrow):
        logp = np.log(pi_sms.copy())
        for c in [0,1]:
            logp[c] += (xrow * np.log(phi_sms[c] + 1e-12)).sum()
        return int(np.argmax(logp))

    yhat_sms = np.array([predict_nb_sms(x) for x in X_sms])
    print("Naive Bayes SMS Spam/Ham Accuracy:", (yhat_sms == y_sms).mean())
    print("-"*50)


# Stage 4c


def showcase_naive_bayes_sklearn():
    docs = [
        ("team wins match", 1), ("player scores goal", 1),
        ("election debate policy", 0), ("policy vote election", 0),
        ("team scores again", 1), ("debate team policy", 0)
    ]
    corpus, y = zip(*docs); y = np.array(y)
    Xtr, Xte, ytr, yte = train_test_split(corpus, y, test_size=0.4, random_state=0, stratify=y)
    vec = CountVectorizer()
    XtrB = vec.fit_transform(Xtr)
    XteB = vec.transform(Xte)

    clf = MultinomialNB(alpha=1.0)
    clf.fit(XtrB, ytr)
    yhat_sk = clf.predict(XteB)
    print("Naive Bayes scikit-learn classification report:")
    print(classification_report(yte, yhat_sk, digits=3))

    cm = confusion_matrix(yte, yhat_sk)
    ConfusionMatrixDisplay(cm, display_labels=["class 0","class 1"]).plot()
    plt.title("Naive Bayes — Confusion Matrix")
    plt.show()
    print("-"*50)


# Stage 7: Bayesian A/B Testing


def post_params(alpha0, beta0, k, n):
    return alpha0 + k, beta0 + (n - k)

def prob_A_better(alphaA, betaA, alphaB, betaB, draws=200_000, seed=0):
    rng = np.random.default_rng(seed)
    thA = rng.beta(alphaA, betaA, size=draws)
    thB = rng.beta(alphaB, betaB, size=draws)
    return float((thA > thB).mean())

def showcase_ab_testing():
    alpha0, beta0 = 1.0, 1.0
    kA, nA = 45, 400
    kB, nB = 62, 420
    aA, bA = post_params(alpha0, beta0, kA, nA)
    aB, bB = post_params(alpha0, beta0, kB, nB)
    p = prob_A_better(aA, bA, aB, bB)
    print("Bayesian A/B Testing: P(theta_A > theta_B | data) =", round(p,4))
    print("-"*50)

# Run all 

if __name__ == "__main__":
    showcase_beta_binomial()
    showcase_gaussian_posterior()
    showcase_ppc_gaussian()
    showcase_naive_bayes_toy()
    showcase_naive_bayes_sms()
    showcase_naive_bayes_sklearn()
    showcase_ab_testing()
